// As a User
// When I click an image
// I expect a lightbox to appear in a modal

// Bonus:

// As a User
// When I click on any image in the bottom row
// I expect to see the entire row in the lightbox as a carousel