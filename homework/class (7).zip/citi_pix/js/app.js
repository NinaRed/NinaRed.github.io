// As a user
// When I change my selection
// I expect the background image to change into the image of my selection